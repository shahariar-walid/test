from flask_sqlalchemy import SQLAlchemy
# Base factory for SQL client
db: SQLAlchemy = SQLAlchemy()